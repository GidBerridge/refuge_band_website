refuge_band_website
===================

Simple HTML / CSS static site for a band. Is expected to get more complex as it gets more content. 
May convert to a Rails site if ecommerce is needed later down the line.
